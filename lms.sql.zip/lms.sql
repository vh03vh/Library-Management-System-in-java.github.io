-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 12, 2022 at 08:31 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `lms`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `bookID` varchar(10) NOT NULL,
  `name` varchar(100) default NULL,
  `publisher` varchar(100) default NULL,
  `price` varchar(10) default NULL,
  `publisherYear` varchar(5) default NULL,
  PRIMARY KEY  (`bookID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bookID`, `name`, `publisher`, `price`, `publisherYear`) VALUES
('1', '1', '1', '1', '1'),
('133', 'OS BOOK', '203', '200', '2018'),
('2', 'math', 'gh.alger', '100', '2015'),
('22200', 'Python', '200', '200', '2013'),
('3', 'PHP', 'GH.Alger', '200', '2013'),
('3513-34', 'system exploitation', '2019', '200', '2015'),
('4', 'cours in java', 'j.jim', '2200', '2015'),
('5', 'intailisation algorithme', '203MHK', '300', '2007'),
('6', 'informatique', '200', '400', '2006');

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `bookID` varchar(10) default NULL,
  `studentID` varchar(10) default NULL,
  `issueDate` varchar(20) default NULL,
  `dueDate` varchar(20) default NULL,
  `returnBook` varchar(5) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue`
--

INSERT INTO `issue` (`bookID`, `studentID`, `issueDate`, `dueDate`, `returnBook`) VALUES
('1', '1', '23-08-2021', '25-08-2021', 'Yes'),
('2', '2', '24-08-2021', '25-08-2021', 'Yes'),
('3', '3', '24-08-2021', '26-08-2021', 'No'),
('4', '4', '06-09-2021', '12-09-2021', 'No'),
('5', '5', '20-09-2021', '27-09-2021', 'No'),
('133', '1919', '30-12-2021', '31-12-2021', 'Yes'),
('3513-34', '39004162', '19-02-2022', '26-02-2022', 'No'),
('22200', '1004', '12-05-2022', '15-05-2022', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentID` varchar(10) NOT NULL,
  `name` varchar(100) default NULL,
  `fatherName` varchar(100) default NULL,
  `courseName` varchar(20) default NULL,
  `branchName` varchar(20) default NULL,
  PRIMARY KEY  (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentID`, `name`, `fatherName`, `courseName`, `branchName`) VALUES
('1', 'safaa belkhier', 'Ethman belkhier', 'B.Tech', 'INFO'),
('1004', 'sami', 'ahmed', 'B.Tech', 'GESTION'),
('1919', 'sabrine bel', 'ahmed bel', 'B.Tech', 'INFO'),
('2', 'Hidaya Belkhier', 'Ethmane Belkhier', 'B.Tech', 'INFO'),
('3', 'hadil sayad', 'ahmed sayad', 'B.Tech', 'INFO'),
('39004162', 'belkhier safaa', 'belkhier athmane', 'B.Tech', 'INFO'),
('4', 'Samad Khawla', 'Samad Ahmed', 'B.Tech', 'INFO'),
('5', 'Malika dabouz', 'ahmed  dabouz', 'B.Tech', 'INFO'),
('6', 'khawla', 'ahmed', 'B.Tech', 'INFO');
